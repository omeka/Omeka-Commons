<?php


class InstallationExhibit extends Omeka_Record
{
    public $id;
    public $installation_id;
    public $orig_id;
    public $url;
    public $title;
    public $description;

    
    
}